export class File {
    path;
    base64Content;
    constructor(path, content) {
        this.path = path;
        this.base64Content = File.base64Encode(content);
    }
    static base64Encode(content) {
        return Buffer.from(content).toString('base64');
    }
}
