import { logger } from '../logger';
import { getErrorMessage } from '../utils';
export class Issue {
    octokit;
    repository;
    issue;
    body;
    constructor(params) {
        this.octokit = params.octokit;
        this.repository = params.repository;
        this.issue = params.issue;
        this.body = params.issue.body;
    }
    async react(reaction) {
        try {
            const { data } = await this.octokit.request('POST /repos/{owner}/{repo}/issues/{issue_number}/reactions', {
                owner: this.repository.owner.login,
                repo: this.repository.name,
                issue_number: this.issue.number,
                content: reaction,
            });
            return data;
        }
        catch (error) {
            logger.error(`Failed to react to issue: ${getErrorMessage(error)}`);
            throw error;
        }
    }
    async comment(...lines) {
        try {
            const { data } = await this.octokit.request('POST /repos/{owner}/{repo}/issues/{issue_number}/comments', {
                owner: this.repository.owner.login,
                repo: this.repository.name,
                issue_number: this.issue.number,
                body: lines.join('\n'),
            });
            return data;
        }
        catch (error) {
            logger.error(`Failed to comment on issue: ${getErrorMessage(error)}`);
            throw error;
        }
    }
    matches(targetTitle) {
        return this.issue.title.toLowerCase().includes(targetTitle.toLowerCase());
    }
}
