import { getErrorMessage } from '../utils';
import { logger } from '../logger';
import { Branch } from './branch';
export class Repository {
    octokit;
    repository;
    _sha = null;
    constructor(params) {
        this.octokit = params.octokit;
        this.repository = params.repository;
    }
    async getSha() {
        if (!this._sha) {
            try {
                const { data } = await this.octokit.request('GET /repos/{owner}/{repo}/branches/{branch}', {
                    owner: this.repository.owner.login,
                    repo: this.repository.name,
                    branch: this.repository.default_branch,
                });
                this._sha = data.commit.sha;
            }
            catch (error) {
                logger.error(`Failed to get latest commit sha: ${getErrorMessage(error)}`);
                throw error;
            }
        }
        return this._sha;
    }
    async createBranch(name) {
        const sha = await this.getSha();
        try {
            const { data } = await this.octokit.request('POST /repos/{owner}/{repo}/git/refs', {
                owner: this.repository.owner.login,
                repo: this.repository.name,
                ref: `refs/heads/${name}`,
                sha,
            });
            return new Branch({
                octokit: this.octokit,
                repository: this.repository,
                ref: data.ref,
            });
        }
        catch (error) {
            logger.error(`Failed to create branch: ${getErrorMessage(error)}`);
            throw error;
        }
    }
}
